@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1" -Nombre "Jaque Libre Personal" -Carpeta "JaqueLibrePersonal" -Archivo "jaque-libre-PC-fuerte.html" -Personal
echo.
pause
