@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1" -Nombre "Jaque Libre" -Carpeta "JaqueLibre" -Archivo "jaque-libre-PC-fuerte.html"
echo.
pause
