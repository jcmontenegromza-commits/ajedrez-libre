@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command "foreach($n in 'Jaque Libre','Jaque Libre Personal'){foreach($f in [Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs')){Remove-Item (Join-Path $f ($n+'.lnk')) -ErrorAction SilentlyContinue}}; Remove-Item (Join-Path $env:LOCALAPPDATA 'JaqueLibre') -Recurse -Force -ErrorAction SilentlyContinue; Remove-Item (Join-Path $env:LOCALAPPDATA 'JaqueLibrePersonal') -Recurse -Force -ErrorAction SilentlyContinue; Write-Host 'Desinstalado.'"
echo.
pause
