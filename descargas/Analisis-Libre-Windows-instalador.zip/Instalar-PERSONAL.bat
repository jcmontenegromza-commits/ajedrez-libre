@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1" -Nombre "Analisis Libre Personal" -Carpeta "AnalisisLibrePersonal" -Archivo "analisis-libre-PC-fuerte.html" -Personal
echo.
pause
