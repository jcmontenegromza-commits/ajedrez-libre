@echo off
title Instalador
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
