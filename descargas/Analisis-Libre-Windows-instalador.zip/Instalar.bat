@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1" -Nombre "Analisis Libre" -Carpeta "AnalisisLibre" -Archivo "analisis-libre-PC-fuerte.html"
echo.
pause
