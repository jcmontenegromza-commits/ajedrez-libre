﻿$ErrorActionPreference = 'Stop'
$Nombre = 'Análisis Libre'
$Version = '1.34'
$Dev = 'Juan Montenegro'
$Archivo = 'analisis-libre-PC-fuerte.html'
$CarpetaDef = Join-Path $env:LOCALAPPDATA 'AnalisisLibre'
$aqui = Split-Path -Parent $MyInvocation.MyCommand.Path
function Pausa($t) { Read-Host $t | Out-Null }
function SiNo($pregunta) { $r = Read-Host ($pregunta + ' Escriba S para sí o N para no, y Enter. Solo Enter es sí'); return -not ($r -match '^[nN]') }

Clear-Host
Write-Host "Bienvenido a la instalación de $Nombre, versión $Version."
Write-Host "Desarrollador: $Dev."
Write-Host ""
Write-Host "Este asistente instala $Nombre en su computadora en 3 pasos: la carpeta, los accesos directos y la copia de los archivos."
Write-Host "Paso 1 de 3."
$r = Read-Host "Para continuar escriba S y presione Enter, que equivale a Siguiente. Para salir escriba C y Enter"
if ($r -match '^[cC]') { Write-Host "Instalación cancelada. No se cambió nada."; Pausa "Presione Enter para cerrar"; exit }

if (-not (Test-Path (Join-Path $aqui $Archivo))) { Write-Host "No encuentro el archivo $Archivo junto a este instalador. Descomprima todo el zip antes de instalar."; Pausa "Presione Enter para cerrar"; exit 1 }

Clear-Host
Write-Host "Paso 2 de 3. Carpeta y accesos directos."
Write-Host "Carpeta de instalación propuesta: $CarpetaDef"
$c = Read-Host "Presione Enter para aceptarla, o escriba otra carpeta completa y Enter"
if ($c.Trim()) { $Carpeta = $c.Trim().Trim('"') } else { $Carpeta = $CarpetaDef }
$escr = SiNo "¿Crear un acceso directo en el Escritorio?"
$inic = SiNo "¿Crear un acceso directo en el menú Inicio?"
Write-Host ""
Write-Host "Resumen: se instalará $Nombre en $Carpeta. Escritorio: $(if($escr){'sí'}else{'no'}). Menú Inicio: $(if($inic){'sí'}else{'no'})."
$r = Read-Host "Escriba S y Enter para Instalar, o C y Enter para cancelar"
if ($r -match '^[cC]') { Write-Host "Instalación cancelada. No se cambió nada."; Pausa "Presione Enter para cerrar"; exit }

Clear-Host
Write-Host "Paso 3 de 3. Instalando $Nombre. Puede tardar un minuto, el archivo es grande."
try {
  New-Item -ItemType Directory -Force -Path $Carpeta | Out-Null
  Write-Host "Copiando los archivos del programa..."
  Copy-Item (Join-Path $aqui $Archivo) (Join-Path $Carpeta $Archivo) -Force
  Copy-Item (Join-Path $aqui 'Desinstalar.bat') (Join-Path $Carpeta 'Desinstalar.bat') -Force
  Copy-Item (Join-Path $aqui 'desinstalar.ps1') (Join-Path $Carpeta 'desinstalar.ps1') -Force
  $dest = Join-Path $Carpeta $Archivo
  $edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
  $uri = ([System.Uri]$dest).AbsoluteUri
  $ws = New-Object -ComObject WScript.Shell
  function Acceso($ruta) {
    $l = $ws.CreateShortcut($ruta)
    if ($edge) { $l.TargetPath = $edge; $l.Arguments = '--app="' + $uri + '"' } else { $l.TargetPath = $dest }
    $l.WorkingDirectory = $Carpeta; $l.Description = $Nombre; $l.Save()
  }
  if ($escr) { Write-Host "Creando el acceso directo del Escritorio..."; Acceso (Join-Path ([Environment]::GetFolderPath('Desktop')) "$Nombre.lnk") }
  if ($inic) { Write-Host "Creando el acceso directo del menú Inicio..."; Acceso (Join-Path ([Environment]::GetFolderPath('Programs')) "$Nombre.lnk") }
  Write-Host "Registrando el programa para poder desinstalarlo desde Configuración..."
  $k = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\AnalisisLibre"
  New-Item -Path $k -Force | Out-Null
  Set-ItemProperty $k DisplayName $Nombre
  Set-ItemProperty $k DisplayVersion $Version
  Set-ItemProperty $k Publisher $Dev
  Set-ItemProperty $k InstallLocation $Carpeta
  Set-ItemProperty $k UninstallString ('"' + (Join-Path $Carpeta 'Desinstalar.bat') + '"')
  Set-ItemProperty $k NoModify 1 -Type DWord
  Set-ItemProperty $k NoRepair 1 -Type DWord
} catch {
  Write-Host "No pude terminar la instalación. El motivo: $($_.Exception.Message)"
  Pausa "Presione Enter para cerrar"; exit 1
}
Write-Host ""
Write-Host "Listo. $Nombre quedó instalado. Desarrollador: $Dev."
if ($escr -or $inic) { Write-Host "Para abrirlo use el acceso directo $Nombre." }
Write-Host "Para quitarlo: Configuración, Aplicaciones, $Nombre, Desinstalar. O ejecute Desinstalar.bat en $Carpeta."
if (SiNo "¿Abrir $Nombre ahora?") { if ($edge) { Start-Process $edge ('--app="' + $uri + '"') } else { Start-Process $dest } }
Pausa "Presione Enter para cerrar el asistente"
