param([string]$Nombre,[string]$Carpeta,[string]$Archivo,[switch]$Personal)
$ErrorActionPreference = 'Stop'
$src = Join-Path $PSScriptRoot $Archivo
if (-not (Test-Path $src)) { Write-Host "No encuentro $Archivo junto al instalador. Descomprimi todo el zip antes de instalar."; exit 1 }
$dest = Join-Path $env:LOCALAPPDATA $Carpeta
New-Item -ItemType Directory -Force -Path $dest | Out-Null
$dst = Join-Path $dest $Archivo
if ($Personal) {
  $t = [IO.File]::ReadAllText($src, [Text.Encoding]::UTF8)
  $t = $t.Replace('/*LICCFG*/{', '/*LICCFG*/{"personal":true,')
  [IO.File]::WriteAllText($dst, $t, (New-Object Text.UTF8Encoding($false)))
} else { Copy-Item $src $dst -Force }
$cands = @(
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")
$browser = $cands | Where-Object { Test-Path $_ } | Select-Object -First 1
$url = ([Uri]$dst).AbsoluteUri
$ws = New-Object -ComObject WScript.Shell
$folders = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))
foreach ($f in $folders) {
  $lnk = $ws.CreateShortcut((Join-Path $f "$Nombre.lnk"))
  if ($browser) { $lnk.TargetPath = $browser; $lnk.Arguments = "--app=`"$url`"" } else { $lnk.TargetPath = $dst }
  $lnk.WorkingDirectory = $dest
  $lnk.Save()
}
Write-Host "Instalado. Busca '$Nombre' en el escritorio o en el menu Inicio."
