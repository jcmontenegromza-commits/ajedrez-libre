@echo off
title Desinstalador
copy /y "%~dp0desinstalar.ps1" "%TEMP%\desinstalar_tmp.ps1" >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%TEMP%\desinstalar_tmp.ps1" -Carpeta "%~dp0."
