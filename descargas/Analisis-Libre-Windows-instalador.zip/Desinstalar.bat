@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command "foreach($n in 'Analisis Libre','Analisis Libre Personal'){foreach($f in [Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs')){Remove-Item (Join-Path $f ($n+'.lnk')) -ErrorAction SilentlyContinue}}; Remove-Item (Join-Path $env:LOCALAPPDATA 'AnalisisLibre') -Recurse -Force -ErrorAction SilentlyContinue; Remove-Item (Join-Path $env:LOCALAPPDATA 'AnalisisLibrePersonal') -Recurse -Force -ErrorAction SilentlyContinue; Write-Host 'Desinstalado.'"
echo.
pause
