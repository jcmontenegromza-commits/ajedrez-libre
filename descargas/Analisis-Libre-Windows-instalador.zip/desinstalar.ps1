﻿param([string]$Carpeta)
$Nombre = 'Análisis Libre'
$Dev = 'Juan Montenegro'
Set-Location $env:TEMP
$Carpeta = (Resolve-Path $Carpeta).Path
Clear-Host
Write-Host "Bienvenido a la desinstalación de $Nombre. Desarrollador: $Dev."
Write-Host "Se va a quitar el programa de $Carpeta, junto con sus accesos directos."
$r = Read-Host "Escriba S y Enter para Siguiente y desinstalar, o C y Enter para cancelar"
if ($r -match '^[cC]') { Write-Host "Desinstalación cancelada. No se cambió nada."; Read-Host "Presione Enter para cerrar" | Out-Null; exit }
try {
  Write-Host "Quitando los accesos directos..."
  Remove-Item (Join-Path ([Environment]::GetFolderPath('Desktop')) "$Nombre.lnk") -Force -ErrorAction SilentlyContinue
  Remove-Item (Join-Path ([Environment]::GetFolderPath('Programs')) "$Nombre.lnk") -Force -ErrorAction SilentlyContinue
  Write-Host "Quitando el registro del programa..."
  Remove-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\AnalisisLibre" -Recurse -Force -ErrorAction SilentlyContinue
  Write-Host "Borrando los archivos..."
  Remove-Item $Carpeta -Recurse -Force -ErrorAction Stop
} catch {
  Write-Host "No pude borrar todo. Cierre $Nombre si está abierto y vuelva a probar. Motivo: $($_.Exception.Message)"
  Read-Host "Presione Enter para cerrar" | Out-Null; exit 1
}
Write-Host "Listo. $Nombre se desinstaló."
Read-Host "Presione Enter para cerrar" | Out-Null
